//
// Created by edward on 22. 5. 13..
//

//#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "linkedlist.h"
#include "textfilewriter.h"

void read_command(char** cmds);

int main(){
    
}

void read_command(char** cmds) {
    
}

