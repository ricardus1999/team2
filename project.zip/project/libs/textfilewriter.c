//
// Created by edward on 22. 5. 13..
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "linkedlist.h"
#include "textfilewriter.h"

void create_music_titles(FILE* stream){

}

void read_file(char* file_name){

}

void write_file(char* file_name){

}
