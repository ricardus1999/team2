//
// Created by edward on 22. 5. 13..
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "linkedlist.h"

static Node* _head = NULL;
static Node* _tail = NULL;
static Node* _cur_node = NULL;

bool empty(){
   
}

size_t size() {
    
}

void print(){
    
}

void print_file(FILE* stream){
    
}

void clear(){
    
}

Node* append_left(size_t n, char new_data[]){
    
}

Node* append(size_t n, char new_data[]){
    
}

Node* _insert_after(Node* cur_node, size_t n, char new_data[]){
    
}

Node* insert_after(Node* cur_node, Node* new_node){
    
}

Node* pop_left(){

}

Node* pop(){
    
}

Node* delete_node(Node* cur_node){
    
}

Node* delete_by_data(char* data){
    
}

Node* next(){
    
}

Node* prev(){
    
}

Node* first_node(){
    
}

Node* last_node(){
    
}

Node* get_node(size_t index){
    
}

